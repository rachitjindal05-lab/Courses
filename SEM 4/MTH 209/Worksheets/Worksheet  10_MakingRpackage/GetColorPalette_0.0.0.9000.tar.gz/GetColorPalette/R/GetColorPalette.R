#' Extract Color Palette from Image
#'
#' This function reads an image and extracts dominant colors using k-means clustering.
#'
#' @param image_path Path to the image file.
#' @param k Number of clusters.
#' @param plot_palette Logical; if TRUE, displays the color palette plot. Default is TRUE.
#'
#' @return A list containing:
#' \itemize{
#'   \item palette: RGB values of cluster centers
#'   \item size: Number of pixels in each cluster
#' }
#'
#' @import imager
#' @importFrom stats kmeans
#' @importFrom grDevices rgb
#'
#' @export
#'
#' @examples
#' \dontrun{
#' get_color_palette("image.jpg", k = 5)
#' }
get_color_palette <- function(image_path, k = 5, plot_palette = TRUE) {
  
  img <- imager::load.image(image_path)
  
  R <- as.vector(img[,,1,1])
  G <- as.vector(img[,,1,2])
  B <- as.vector(img[,,1,3])
  
  D <- matrix(c(R, G, B), ncol = 3)
  colnames(D) <- c("R", "G", "B")
  
  set.seed(1)
  kmeans_result <- stats::kmeans(D, centers = k)
  
  palette_colors <- kmeans_result$centers
  cluster_size <- kmeans_result$size
  
  if (plot_palette) {
    plot(1:k, rep(1, k),
         col = grDevices::rgb(palette_colors),
         pch = 15,
         cex = 5,
         xlab = "Cluster",
         ylab = "",
         main = "Color Palette")
  }
  
  return(list(
    palette = palette_colors,
    size = cluster_size
  ))
}